import module_manager
module_manager.review()
import nltk
